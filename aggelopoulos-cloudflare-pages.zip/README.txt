# Aggelopoulos Carpentry — Cloudflare Pages
1) Ανέβασε αυτό το φάκελο σε GitHub (new repo → upload files → commit).
2) Cloudflare Pages → Create Project → Connect to Git → διάλεξε το repo.
3) Build settings: Framework **None**, Build command **(κενό)**, Output directory **/**.
4) Μετά το deploy, πρόσθεσε Custom Domain (`aggelopouloscarpentry.com`).
5) Στη σελίδα /επικοινωνία/ άλλαξε το Formspree action με το δικό σου Form ID.
6) Αν χρειαστούν ανακατευθύνσεις, συμπλήρωσε το αρχείο `_redirects`.
